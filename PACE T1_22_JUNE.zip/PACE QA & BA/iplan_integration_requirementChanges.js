
1.search for request json

For all ->
GET
https://dev-att.siteforge.com/apim/sitm/4.0/rest/IntegrationHandler/search/v1?_s=id=ge=0;(integrationType==Iplan)&orderBy=id&orderType=asc&llimit=0&ulimit=24


For Specific:->
https://dev-att.siteforge.com/apim/sitm/4.0/rest/IntegrationHandler/search/v1?_s=id=ge=0;(integrationType==Iplan;entityId==iplanjobnumber)&orderBy=id&orderType=asc&llimit=0&ulimit=24



2. create data== 

POST
https://dev-att.siteforge.com/apim/sitm/4.0/rest/IntegrationHandler/create/v1

{"requestJson":{"header": {"eventKey": "abc123", "eventType": "Create", "applicationKey": "iPlan", "messageTimeStamp": "2016-12-02 00:00:00"}, "recordData": {"usid": "", "city": "City", "state": "State", "county": "County", "status": "YET_TO_START", "vendor": "Vendor1", "address": "abc address", "jobName": "jobName1", "jobType": "Custom ID", "mODCode": "MODCode12", "latitude": "1.24", "siteName": "SiteName1", "spectrum": "iPlanSpectrum1", "bandwidth": "94.3MHz", "longitude": "1.2", "oraclePTN": "OraclePTN12", "Technology": "5G", "companyCode": "CompanyCode1", "associatedFA": "AssociatedFA2", "jobScopeName": "Outdoor", "productGroup": "ProductGroup1", "faLocationCode": "USID1", "iPlanJobNumber": "job1", "productSubgroup": "ProductSubGroup1", "cFASProjectNumber": "CFASProjectNumber", "productDescription": "ProductDescription1", "faassociatedDescription": "FAAssociatedDescription1","rcpJobNumber":"rcpJobNumber1"}}, "status":"ENQUEUED","integrationType":"IPlan"}


3. update data== 
POST
https://dev-att.siteforge.com/apim/sitm/4.0/rest/IntegrationHandler/create/v1

{"requestJson":{"header":{"eventKey":"abc123","eventType":"Update","messageTimeStamp":"2016-12-02 00:00:00","applicationKey":"iPlan"},"recordData":{"associatedFA":"abc123","band":"abc123","bandwidth":"94.3MHz","cfasProjectNumber":"abc123","city":"city1","county":"county1","faassociatedDescription":"abc123 abc123 abc123 abc123","faLocationCode":"USID1","iPlanJobNumber":"job1","rcpJobNumber":"rcpJobNumber1"}}, "status":"ENQUEUED","integrationType":"IPlan"}


=======================================================================================================================================================

SEARCH==

GET
4. https://dev-att.siteforge.com/apim/autoform2/1.0.0/rest/IPlanIntegration/search?_s=id=ge=0;(iplanJobNumber==job1)&orderBy=id&orderType=desc&llimit=24&ulimit=0





